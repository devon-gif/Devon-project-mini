
  # Glassmorphism Mini-CRM Design

  This is a code bundle for Glassmorphism Mini-CRM Design. The original project is available at https://www.figma.com/design/1J5bfBqQ24MsfAiEi5D0RF/Glassmorphism-Mini-CRM-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  